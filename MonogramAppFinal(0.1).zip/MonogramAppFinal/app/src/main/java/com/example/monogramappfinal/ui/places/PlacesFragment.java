package com.example.monogramappfinal.ui.places;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.monogramappfinal.Adapters.ItemAdapter;
import com.example.monogramappfinal.R;
import com.example.monogramappfinal.databinding.FragmentPlacesBinding;

public class PlacesFragment extends Fragment {

    private FragmentPlacesBinding binding;

    RecyclerView recycler_view;

    public static String s1[], s2[];
    public static int images[] = {R.drawable.android, R.drawable.linux, R.drawable.apple};

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentPlacesBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        PlacesViewModel placesViewModel =
                new ViewModelProvider(this).get(PlacesViewModel.class);

        recycler_view = root.findViewById(R.id.recycler_view);

        s1 = getResources().getStringArray(R.array.sample_names);
        s2 = getResources().getStringArray(R.array.sample_descriptions);

        ItemAdapter adapter = new ItemAdapter(getContext(), s1, s2,images);

        recycler_view.setAdapter(adapter);
        recycler_view.setLayoutManager(new LinearLayoutManager(getContext()));


        final TextView textView = binding.textPlaces;
        placesViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
        return root;
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}